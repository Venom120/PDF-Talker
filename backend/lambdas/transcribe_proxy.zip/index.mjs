import { TranscribeStreamingClient, StartStreamTranscriptionCommand } from "@aws-sdk/client-transcribe-streaming";
import { ApiGatewayManagementApiClient, PostToConnectionCommand } from "@aws-sdk/client-apigatewaymanagementapi";

// Initialize clients
const transcribeClient = new TranscribeStreamingClient({ region: "ap-south-1" });
const apiGatewayClient = new ApiGatewayManagementApiClient({ endpoint: process.env.API_GW_ENDPOINT });

export const handler = async (event) => {
    const routeKey = event.requestContext.routeKey;
    const connectionId = event.requestContext.connectionId;

    if (routeKey === '$connect' || routeKey === '$disconnect') {
        return { statusCode: 200, body: `Connected/Disconnected.` };
    }

    if (routeKey === '$default') {
        try {
            const body = JSON.parse(event.body);
            const audio_b64 = body.audio_data;

            if (!audio_b64) {
                return { statusCode: 400, body: 'Missing audio_data.' };
            }

            const audioChunk = Buffer.from(audio_b64, 'base64');

            // Create an async generator for the audio stream
            async function* audioStream() {
                yield { AudioEvent: { AudioChunk: audioChunk } };
            }

            // Prepare the Transcribe command
            const command = new StartStreamTranscriptionCommand({
                LanguageCode: "en-US",
                MediaSampleRateHertz: 16000,
                MediaEncoding: "pcm",
                AudioStream: audioStream(),
            });

            const response = await transcribeClient.send(command);

            let finalTranscript = "";
            for await (const event of response.TranscriptResultStream) {
                if (event.TranscriptEvent.Transcript.Results && !event.TranscriptEvent.Transcript.Results[0].IsPartial) {
                    finalTranscript += event.TranscriptEvent.Transcript.Results[0].Alternatives[0].Transcript + " ";
                }
            }

            // Send the final transcript back to the client
            if (finalTranscript) {
                const postToConnectionCommand = new PostToConnectionCommand({
                    ConnectionId: connectionId,
                    Data: JSON.stringify({ transcript: finalTranscript.trim() }),
                });
                await apiGatewayClient.send(postToConnectionCommand);
            }

        } catch (error) {
            console.error("Error in default route:", error);
            return { statusCode: 500, body: JSON.stringify(error.message) };
        }
    }

    return { statusCode: 200 };
};